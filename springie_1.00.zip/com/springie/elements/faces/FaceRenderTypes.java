package com.springie.elements.faces;

public interface FaceRenderTypes {
  //public static final int INVISIBLE = 0;

  int CONCENTRIC = 1;

  int SEGMENTED = 2;
  
  int CLOCKWISE = 5;
  
  int ANTI_CLOCKWISE = 6;
}