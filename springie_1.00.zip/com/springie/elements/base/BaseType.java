package com.springie.elements.base;

public class BaseType {
  public boolean hidden;
  public boolean selected;
  public boolean disabled;
  public int radius;
  public int log_mass;
}
