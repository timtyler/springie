package com.springie.elements.base;

import com.springie.elements.clazz.Clazz;

public class BaseElement {
  public Clazz clazz = new Clazz(0xffff8000);
  
  //public BaseType type;
}