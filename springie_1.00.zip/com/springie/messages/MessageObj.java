package com.springie.messages;

public class MessageObj {
  public int type;
  public int data1;
  public int data2;

  public MessageObj(int t, int d1, int d2) {
    this.type = t;
    this.data1 = d1;
    this.data2 = d2;
  }
}
