package com.springie.messages;

public interface ArgumentList {
  Object getArguments(int i);
}