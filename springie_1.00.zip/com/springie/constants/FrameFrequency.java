package com.springie.constants;

public interface FrameFrequency {
  int _FRAME_1 = 0;
  int _FRAME_2 = 1;
  int _FRAME_4 = 3;
  int _FRAME_8 = 7;
  int _FRAME_16 = 15;
  int _FRAME_32 = 31;
}
