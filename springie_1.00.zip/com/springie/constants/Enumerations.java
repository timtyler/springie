package com.springie.constants;

public interface Enumerations {
  //int _SIMPLE = 0;
  //int _SIZES = 1;
}
