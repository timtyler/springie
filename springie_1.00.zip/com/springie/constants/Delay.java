package com.springie.constants;

public interface Delay {
  int _DELAY_0 = 0;
  int _DELAY_1 = 1;
  int _DELAY_2 = 2;
  int _DELAY_5 = 5;
  int _DELAY_10 = 10;
  int _DELAY_20 = 20;
  int _DELAY_50 = 50;
  int _DELAY_100 = 100;
  int _DELAY_200 = 200;
  int _DELAY_512 = 512;
}
