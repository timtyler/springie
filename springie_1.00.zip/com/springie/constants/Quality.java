package com.springie.constants;

public interface Quality {
  int THICK_OUTLINE = 0;
  int SOLID = 1;
  int _QUALITY_1A = 2;
  int MULTIPLE = 3;
  int _QUALITY_3 = 4;
  int _QUALITY_3A = 5;
  int _QUALITY_4 = 6;
  int _QUALITY_4A = 7;
  int _QUALITY_5 = 8;
  int _QUALITY_6 = 9;
  //int _QUALITY_2A = 5;
  //int THIN_OUTLINE = 1;
}
