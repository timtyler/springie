// This code has been placed into the public domain by its author
package com.springie.constants;

// This code has been placed into the public domain by its author
public interface ToolTypes {

  int _PENCIL = 0;

  int _MACHINE = 2;

  int _BRUSH = 1;

  int _SPRAY = 3;

  int _POTATO = 4;
}
