//This code has been placed into the public domain by its author
package com.springie.constants;

public interface StartupTypes {
  int _FOOTBALL = 1;
  int _ICOSAHEDRON = 2;
  int _TETRAHEDRON = 3;
  int _HEX_IN_12 = 4;
  int _HEX_OUT_12 = 5;

  int _DOME = 34;
  int _MESH = 35;
  int _CABLE = 36;
  int _RIBBON_RECT = 37;
  int _RIBBON_TRI = 38;
  int _TETRAHELIX = 39;
}
