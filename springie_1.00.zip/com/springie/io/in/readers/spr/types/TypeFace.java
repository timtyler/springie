// * Read in information from files...

package com.springie.io.in.readers.spr.types;

public class TypeFace extends TypeBase {
  // nothing yet...
}
