package com.springie.presets;

public interface ProceduralObject {
  ProceduralObjectInstance free_nodes = new ProceduralObjectInstance();

  ProceduralObjectInstance sphere_pack = new ProceduralObjectInstance();

  ProceduralObjectInstance tube = new ProceduralObjectInstance();

  ProceduralObjectInstance matrix = new ProceduralObjectInstance();
}