package com.springie.presets;

public class ProceduralObjectInstance {
  //...
}