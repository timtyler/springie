// This program has been placed into the public domain by its author.

package com.springie.gui.components;

class TTNumStr {
  int number;

  String string;

  TTNumStr(int n, String s) {
    this.number = n;
    this.string = s;
  }
}