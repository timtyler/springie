//This code has been placed into the public domain by its author
package com.springie.gui;


public class PreferenceGUIValues {
//...
}
