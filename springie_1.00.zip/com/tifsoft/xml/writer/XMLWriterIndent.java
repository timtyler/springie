package com.tifsoft.xml.writer;

public interface XMLWriterIndent {
  int level = 1;
}
