package com.tifsoft.xml.writer;

public interface XMLWriterInterface {
  String makeString();
  String makeString(int n);
}
