package com.tifsoft.xml.driver;

class StateCommentInstance {
  //...
}