package com.tifsoft.xml.driver;

interface ConstantsErrorMessages {
  String LT_INSIDE_LT = "Nested '<' symbols found";
  String MISMATCHED = "Closing element: ";
  String DOES_NOT_MATCH = " ...does not match opening element: ";
  String MISPLACED_QUOTE = "Misplaced quote";
}
